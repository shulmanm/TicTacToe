python3 Server.py <<< "localhost:8000" &
python3 TicTacToe_client.py <<< "localhost:8000" &
python3 TicTacToe_client.py <<< "localhost:8000" &
